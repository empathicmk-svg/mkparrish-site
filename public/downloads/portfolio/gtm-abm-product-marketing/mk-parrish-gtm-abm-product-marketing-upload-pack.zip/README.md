# MK Parrish GTM ABM Product Marketing Pack

## Live URLs after deploy

- Microsite: https://www.mkparrish.com/portfolio
- Upload index: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/index.html
- ZIP: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-gtm-abm-product-marketing-upload-pack.zip

## New polished documents

- GTM, ABM, and Product Marketing Portfolio Pack
  - PDF: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-gtm-abm-product-marketing-pack.pdf
  - HTML: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-gtm-abm-product-marketing-pack.html
- GTM and ABM One-Sheet
  - PDF: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-gtm-abm-one-sheet.pdf
  - HTML: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-gtm-abm-one-sheet.html
- ABM Campaign Room
  - PDF: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-abm-campaign-room.pdf
  - HTML: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-abm-campaign-room.html
- Product Marketing Message House
  - PDF: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-product-marketing-message-house.pdf
  - HTML: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-product-marketing-message-house.html
- Social and Substack Content Kit
  - PDF: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-social-substack-content-kit.pdf
  - HTML: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-social-substack-content-kit.html
- Social Posts Swipe File
  - Markdown: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-social-posts.md
  - Text: https://www.mkparrish.com/downloads/portfolio/gtm-abm-product-marketing/mk-parrish-social-posts.txt

## Original proof samples included

- Brand Voice Playbook
- Build Copy Guide
- Rewrite Playbook
- Rewrite Starter Checklist
- Ghostwriting Playbook
- The Margin Notes Vol. III
